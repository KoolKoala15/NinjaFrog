#include <GamePlay/Spike.h>


bool Spike::init(const EnemyDescriptor& enemyDescriptor)
{
    return Enemy::init(enemyDescriptor);
}

void Spike::update(float deltaMilliseconds)
{

}
