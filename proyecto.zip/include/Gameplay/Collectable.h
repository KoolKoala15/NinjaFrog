#pragma once

#include <Gameplay/Entity.h>

class Collectable : public Entity
{
public:
	int m_type{ 0 };

};