#pragma once

const float gravity = 9.8f / 10000.0f;
constexpr float millisecondsToSeconds = 1 / 1000.f;