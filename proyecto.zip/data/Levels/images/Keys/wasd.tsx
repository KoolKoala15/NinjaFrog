<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="wasd" tilewidth="32" tileheight="32" tilecount="16" columns="2">
 <image source="wasd.png" width="64" height="256"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="1000"/>
   <frame tileid="1" duration="1000"/>
  </animation>
 </tile>
 <tile id="2">
  <animation>
   <frame tileid="2" duration="1000"/>
   <frame tileid="3" duration="1000"/>
  </animation>
 </tile>
 <tile id="4">
  <animation>
   <frame tileid="4" duration="1000"/>
   <frame tileid="5" duration="1000"/>
  </animation>
 </tile>
 <tile id="6">
  <animation>
   <frame tileid="7" duration="1000"/>
   <frame tileid="6" duration="1000"/>
  </animation>
 </tile>
 <tile id="8">
  <animation>
   <frame tileid="8" duration="1000"/>
   <frame tileid="9" duration="1000"/>
  </animation>
 </tile>
 <tile id="10">
  <animation>
   <frame tileid="10" duration="1000"/>
   <frame tileid="11" duration="1000"/>
  </animation>
 </tile>
 <tile id="12">
  <animation>
   <frame tileid="13" duration="1000"/>
   <frame tileid="12" duration="1000"/>
  </animation>
 </tile>
 <tile id="14">
  <animation>
   <frame tileid="15" duration="1000"/>
   <frame tileid="14" duration="1000"/>
  </animation>
 </tile>
</tileset>
