<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Conjunto01" tilewidth="16" tileheight="16" tilecount="242" columns="22" objectalignment="topleft" tilerendersize="grid">
 <grid orientation="orthogonal" width="32" height="32"/>
 <image source="../Terrain/Terrain (16x16).png" width="352" height="176"/>
</tileset>
