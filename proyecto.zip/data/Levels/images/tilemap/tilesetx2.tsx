<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="tilesetx2" tilewidth="32" tileheight="32" tilecount="242" columns="22">
 <image source="../Terrain/Terrain (32x32).png" width="704" height="352"/>
</tileset>
