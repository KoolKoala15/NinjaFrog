<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="fruits" tilewidth="32" tileheight="32" tilecount="8" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="0"/>
  </properties>
  <image source="../../../Images/Collectables/Apple.png" width="544" height="32"/>
 </tile>
 <tile id="1" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="1"/>
  </properties>
  <image source="../../../Images/Collectables/Bananas.png" width="544" height="32"/>
 </tile>
 <tile id="2" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="2"/>
  </properties>
  <image source="../../../Images/Collectables/Cherries.png" width="544" height="32"/>
 </tile>
 <tile id="3" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="3"/>
  </properties>
  <image source="../../../Images/Collectables/Kiwi.png" width="544" height="32"/>
 </tile>
 <tile id="4" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="4"/>
  </properties>
  <image source="../../../Images/Collectables/Melon.png" width="544" height="32"/>
 </tile>
 <tile id="5" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="5"/>
  </properties>
  <image source="../../../Images/Collectables/Orange.png" width="544" height="32"/>
 </tile>
 <tile id="6" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="6"/>
  </properties>
  <image source="../../../Images/Collectables/Pineapple.png" width="544" height="32"/>
 </tile>
 <tile id="7" x="0" y="0" width="32" height="32">
  <properties>
   <property name="Type" type="int" value="7"/>
  </properties>
  <image source="../../../Images/Collectables/Strawberry.png" width="544" height="32"/>
 </tile>
</tileset>
