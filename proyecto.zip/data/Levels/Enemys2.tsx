<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="Enemys2" tilewidth="32" tileheight="32" tilecount="2" columns="1">
 <image source="images/tilemap/Enemys2.png" width="32" height="64"/>
</tileset>
